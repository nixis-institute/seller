# url_launcher_example

Demonstrates how to use the url_launcher plugin.

## Getting Started

For help getting started with Flutter, view our online
[documentation](http://flutter.io/).
