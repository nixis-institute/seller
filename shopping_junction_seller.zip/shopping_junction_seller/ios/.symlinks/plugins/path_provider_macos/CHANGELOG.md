## 0.0.4

* Adds an example app to run integration tests.

## 0.0.3+1

* Make the pedantic dev_dependency explicit.

## 0.0.3

* Added support for user's downloads directory.

## 0.0.2+1

* Update README.

## 0.0.1

* Initial open source release.