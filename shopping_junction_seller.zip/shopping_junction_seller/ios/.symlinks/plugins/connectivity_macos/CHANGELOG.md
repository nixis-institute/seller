## 0.1.0+2

* Remove hard coded ios workspace setting of the example app.

## 0.1.0+1

* Make the pedantic dev_dependency explicit.

## 0.1.0

* Adds an example app to trigger CI tests. Bumped the MINOR version to
avoid compatibility issues once this packages is endorsed.

## 0.0.2+1

* Add CHANGELOG.

## 0.0.1

* Initial open source release.