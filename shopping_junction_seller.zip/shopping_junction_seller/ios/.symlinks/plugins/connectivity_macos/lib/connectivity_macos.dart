// Analyze will fail if there is no main.dart file. This file should
// be removed once an example app has been added to connectivity_macos.
// https://github.com/flutter/flutter/issues/51007
