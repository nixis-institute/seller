import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shopping_junction_seller/BLOC/products_bloc/products_bloc.dart';
import 'package:shopping_junction_seller/models/productModel.dart';


class SubProductScreen extends StatefulWidget{
  String id,name;
  SubProductScreen(this.id,this.name);
  @override
  _SubProductScreen createState() => _SubProductScreen();
}

class _SubProductScreen extends State<SubProductScreen>
{
  ProductsBloc _productsBloc;
  void initState()
  {
    super.initState();
    _productsBloc = ProductsBloc();
    _productsBloc.add(
      OnSubProducts(this.widget.id)
    );
  }

  @override


  Widget build(BuildContext context)
  {
    return Scaffold(
      appBar: AppBar(title: Text(this.widget.name),),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
      floatingActionButton: FloatingActionButton.extended(
      onPressed: (){
        // Navigator.push(context, MaterialPageRoute(builder: 
        // (_)=>AddProduct(
        
        // // state.products[index].id,state.products[index].name
        // )));  
      },
      
      tooltip: 'Add Varient',
      icon: Icon(Icons.add),
      label: Text("Add Varient")
      ),



      body: BlocBuilder<ProductsBloc,ProductsState>(
        bloc: _productsBloc,
        builder: (context,state){
          if(state is ProductsLoading)
          {
            return Center(child: CircularProgressIndicator(),);
          }
          if(state is LoadSubProduct){
            List<SubProductModel>  products = state.products; 
            print(products);
            // return Text("loaded");

            return Container(
              // padding: EdgeInsets.all(10),
              child: ListView.builder(
              
              // separatorBuilder: (context, index) => Divider(
              // color: Colors.grey[0],
              // height: 0,
              // ),


                itemCount: products.length,  
                itemBuilder: (context,i)
                {
                  return Container(
                    padding: EdgeInsets.only(right:5,left:5,bottom: 5),
                    child: Card(
                      // elevation: 0,
                      child: Container(
                        // height: 100,
                        padding: EdgeInsets.all(10),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: <Widget>[
                                
                                Text(
                                  sizePicker[products[i].size.toString()],
                                  style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),
                                ),

                                
                                ListView.builder(
                                  shrinkWrap: true,
                                  itemCount: products[i].product.length,
                                  itemBuilder: (context,j){
                                    return Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: <Widget>[  
                                        SizedBox(height: 10,),
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: <Widget>[


                                            // Text(products[i].product[j].color),




                                            Row(
                                              children: <Widget>[
                                                Container(
                                                  padding: EdgeInsets.all(3),
                                                  height: 20,
                                                  width: 20,
                                                  decoration: BoxDecoration(
                                                    border: Border.all(width:0.2,color:Colors.grey),
                                                    color: Color(int.parse(products[i].product[j].color.toString().replaceAll("#", "0xff"))),
                                                    borderRadius: BorderRadius.circular(50)
                                                    ),
                                                // child:
                                                ),
                                                SizedBox(width: 10,),
                                                  Text(
                                                  colorsPicker[products[i].product[j].color.toString()],
                                                  style: TextStyle(color: Colors.black),
                                                ),
                                                SizedBox(width: 10,),
                                                Icon(Icons.add_circle_outline,color: Colors.grey,)


                                              ],
                                            ),







                                            Row(
                                              children: <Widget>[
                                                Text("\u20B9 "+ products[i].product[j].mrp.toString(),
                                                style: TextStyle(fontWeight: FontWeight.bold),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                        
                                      ],
                                    );
                                  }
                                ),

                                SizedBox(height:5),
                                Center(child: Text('Add Color',style: TextStyle(color: Colors.green),))




                                // widget(
                                //   child: Row(
                                //     children: <Widget>[
                                //       Text(products[i].product[0].color),
                                //       Text(products[i].product[0].mrp.toString()),
                                //     ],
                                //   ),
                                // )


                              ],
                            ),

                            // Text(
                            //   products[i].mrp.toString()
                            // ),                
                            // Text(
                            //   products[i].size
                            // ),
                            // Text(
                            //   products[i].qty.toString()
                            // ),
                          ],
                        ),
                      ),
                    ),
                  );
                }
                ),
            );

          }
          else{
            return Text("error");
          }
        }
      
      )
    );

  }
}